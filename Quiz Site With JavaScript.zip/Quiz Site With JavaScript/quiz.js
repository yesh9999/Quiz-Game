(function() 
 {
  var allQuestions = [];
  
  var quesCounter = -1;
  var selectOptions = [];
  var quizSpace = $('#quiz');
  var level;
  var timer;
  
  loadData();
  start();
  // nextQuestion();

    
  $('#next').click(function () 
    {
        chooseOption();
        console.log(level,selectOptions);
        if (quesCounter!=-1 && isNaN(selectOptions[quesCounter])) 
        {
            alert('Please select an option !');
        } 
        else 
        {
          quesCounter++;
          nextQuestion();
        }
    });
  
  $('#prev').click(function () 
    {
        chooseOption();
        quesCounter--;
        nextQuestion();
    });
  
  function start(){
   
    var element = $('<div>',{id: 'question'});
    var header = $('<h2>Choose the level:</h2>');
    element.append(header);

    var radioItems = $('<ul>');
    var item;
    var input = '';
    let arr = ['Easy','Medium','Hard'];

    for (var i = 0; i < arr.length; i++) {
      item = $('<li>');
      input = '<input type="radio" name="answer" value=' + i + ' />';
      input += arr[i];
      item.append(input);
      radioItems.append(item);
    }
      
    element.append(radioItems)
    quizSpace.append(element).fadeIn();       
  }

  function loadData(){
    var json = null;
    $.ajax({
      'async': false,
      'global': false,
      'url': "./questions.json",
      'dataType': "json",
      'success': function(data) {
        json = data;
      }
    });
    console.log('json',json);
    allQuestions = json;
  }

  function setTimer()
  {
      var minute = 0;
      var sec = 30;
      timer = setInterval(function() {
        sec--;
        document.getElementById("timer").innerHTML = "TIME LEFT : "+ sec ;

        if (sec == 00) {
          if (minute == 0) {
            alert('times up!')
            chooseOption();
            quesCounter =5;
            nextQuestion();
            clearInterval(timer);
          }
          minute --;
          sec = 60;
        }

      }, 1000);
  }
  function createElement(index) 
    {
        var element = $('<div>',{id: 'question'});
        var header = $('<h2>Question No. ' + (index + 1) + ' :</h2>');
        element.append(header);

        var question = $('<p>').append(allQuestions[index].question);
        element.append(question);

        var radio = radioButtons(index);
        element.append(radio);

        return element;
    }
  
  function radioButtons(index) 
    {
        var radioItems = $('<ul>');
        var item;
        var input = '';
        for (var i = 0; i < allQuestions[index].options.length; i++) {
          item = $('<li>');
          input = '<input type="radio" name="answer" value=' + i + ' />';
          input += allQuestions[index].options[i];
          item.append(input);
          radioItems.append(item);
        }
        return radioItems;
  }
  
  function chooseOption() 
    {
      if(quesCounter!=-1){
        selectOptions[quesCounter] = +$('input[name="answer"]:checked').val();
      } else{
        level = +$('input[name="answer"]:checked').val();
        
        allQuestions= allQuestions.filter(x => x.level==level)
        console.log('all', allQuestions)
        setTimer();

      }
    }
   
  function nextQuestion() 
    {
        quizSpace.fadeOut(function() 
            {
              $('#question').remove();
              if(quesCounter < allQuestions.length)
                {
                    var nextQuestion = createElement(quesCounter);
                    quizSpace.append(nextQuestion).fadeIn();
                    if (!(isNaN(selectOptions[quesCounter]))) 
                    {
                      $('input[value='+selectOptions[quesCounter]+']').prop('checked', true);
                    }
                    if(quesCounter === 1)
                    {
                      $('#prev').show();
                    } 
                    else if(quesCounter === 0)
                    {
                      $('#prev').hide();
                      $('#next').show();
                    }
                }
              else 
                {
                    var scoreRslt = displayResult();
                    quizSpace.append(scoreRslt).fadeIn();
                    $('#next').hide();
                    $('#prev').hide();
                }
        });
    }
  
  function displayResult() 
    {
        clearInterval(timer);

        var score = $('<p>',{id: 'question'});
        var correct = 0;
        for (var i = 0; i < selectOptions.length; i++) 
        {
          if (selectOptions[i] === allQuestions[i].answer) 
          {
            correct++;
          }
        }
        var s = 'You scored ' + correct + ' out of ' +allQuestions.length +' : ';
        if(correct==0)
        {
          s =s + "\nPOOR"
        } else if(correct ==1)
        {
          s =s + "\nPOOR"
        }else if(correct ==2)
        {
          s =s + "\BAD"
        }else if(correct ==3)
        {
          s =s + "\nGOOD"
        }else if(correct ==4)
        {
          s =s + "\nSTRONG"
        }else {
          s =s + "\nVERY STRONG"
        }

        for(var i=0;i<allQuestions.length;i++){
          x = allQuestions[i]
          s = s + `<br><br>Question: ${x.question}<br>Answer: ${x.options[x.answer]}`
        }
        
        score.append(s);
        return score;
  }
})();